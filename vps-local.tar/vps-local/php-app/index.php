<?php
$host = getenv('DB_HOST') ?: 'mysql';
$user = getenv('DB_USER') ?: 'devuser';
$pass = getenv('DB_PASS') ?: 'devpass';
$db   = getenv('DB_NAME') ?: 'devdb';

header('Content-Type: application/json');

try {
    $pdo  = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $stmt = $pdo->query("SELECT * FROM users LIMIT 50");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'service' => 'PHP',
        'status'  => 'running',
        'version' => PHP_VERSION,
        'db'      => 'connected',
        'users'   => $rows,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'service' => 'PHP',
        'status'  => 'running',
        'version' => PHP_VERSION,
        'db'      => 'error: ' . $e->getMessage(),
    ]);
}
