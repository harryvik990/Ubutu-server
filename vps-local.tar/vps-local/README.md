# 🖥️ VPS Local Dev Environment

A Docker Compose setup for local project testing with **Node.js**, **Python/Flask**, and **PHP**, all behind an **Nginx** reverse proxy with a shared **MySQL 8** database.

---

## 📦 Services & Ports

| Service    | Container    | Port  | URL                          |
|------------|--------------|-------|------------------------------|
| Nginx      | vps_nginx    | 80    | http://localhost/            |
| Node.js    | vps_node     | 3000  | http://localhost/node/       |
| Python     | vps_python   | 5000  | http://localhost/python/     |
| PHP        | vps_php      | 9000  | http://localhost/php/        |
| MySQL      | vps_mysql    | 3306  | localhost:3306               |
| Adminer    | vps_adminer  | 8080  | http://localhost:8080        |

---

## 🚀 Quick Start

### Prerequisites
- [Docker Desktop](https://www.docker.com/products/docker-desktop/) (Mac/Windows)  
  or `docker` + `docker compose` CLI on Linux

### 1. Start everything
```bash
make up
# or
docker compose up -d --build
```

### 2. Check services are running
```bash
make ps
```

### 3. Open in browser
- **Overview:** http://localhost/
- **Node.js:** http://localhost/node/health
- **Python:** http://localhost/python/health
- **PHP:** http://localhost/php/index.php
- **Adminer DB GUI:** http://localhost:8080

---

## 🗄️ Database Credentials

| Field    | Value     |
|----------|-----------|
| Host     | `mysql`   |
| Port     | `3306`    |
| Database | `devdb`   |
| User     | `devuser` |
| Password | `devpass` |

> Root password: `rootpass`

---

## 🛠️ Useful Commands

```bash
make up           # Start all services
make down         # Stop all services
make logs         # Tail all logs
make logs-node    # Tail Node.js logs only
make ps           # List containers and status
make build        # Rebuild images (no cache)
make clean        # Remove containers + volumes

make shell-node   # Open shell in Node container
make shell-python # Open shell in Python container
make shell-php    # Open shell in PHP container
make shell-mysql  # Open MySQL CLI
```

---

## 📁 Project Structure

```
vps-local/
├── docker-compose.yml
├── Makefile
├── nginx/
│   └── conf.d/
│       └── default.conf       # Reverse proxy config
├── node-app/
│   ├── Dockerfile
│   ├── package.json
│   └── index.js               # Express starter
├── python-app/
│   ├── Dockerfile
│   ├── requirements.txt
│   └── app.py                 # Flask starter
├── php-app/
│   ├── Dockerfile
│   └── index.php              # PHP starter
└── mysql-data/                # Persistent DB volume (auto-created)
```

---

## 🔄 Hot Reload

- **Node.js** — uses `nodemon`, auto-restarts on file changes in `node-app/`
- **Python** — Flask debug mode enabled, auto-reloads on changes in `python-app/`
- **PHP** — php-fpm serves files directly; just edit files in `php-app/`

---

## 🧹 Teardown

```bash
make clean   # removes containers AND database volume
```
