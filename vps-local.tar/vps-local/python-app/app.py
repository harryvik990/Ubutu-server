import os
from flask import Flask, jsonify
import mysql.connector

app = Flask(__name__)

def get_db():
    return mysql.connector.connect(
        host    = os.getenv("DB_HOST", "mysql"),
        user    = os.getenv("DB_USER", "devuser"),
        password= os.getenv("DB_PASS", "devpass"),
        database= os.getenv("DB_NAME", "devdb"),
    )

@app.route("/")
def index():
    return jsonify(service="Python/Flask", status="running", version="3.11")

@app.route("/health")
def health():
    try:
        conn = get_db()
        conn.close()
        return jsonify(status="ok", db="connected")
    except Exception as e:
        return jsonify(status="error", db=str(e)), 500

@app.route("/users")
def users():
    try:
        conn   = get_db()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users LIMIT 50")
        rows = cursor.fetchall()
        cursor.close()
        conn.close()
        return jsonify(rows)
    except Exception as e:
        return jsonify(error=str(e)), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
