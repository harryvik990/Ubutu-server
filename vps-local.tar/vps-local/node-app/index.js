const express = require("express");
const mysql   = require("mysql2/promise");

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// ── DB connection pool ────────────────────────────────────────────────────────
const pool = mysql.createPool({
  host    : process.env.DB_HOST || "mysql",
  user    : process.env.DB_USER || "devuser",
  password: process.env.DB_PASS || "devpass",
  database: process.env.DB_NAME || "devdb",
});

// ── Routes ────────────────────────────────────────────────────────────────────
app.get("/", (req, res) => {
  res.json({ service: "Node.js", status: "running", version: process.version });
});

app.get("/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ status: "ok", db: "connected" });
  } catch (err) {
    res.status(500).json({ status: "error", db: err.message });
  }
});

app.get("/users", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM users LIMIT 50");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`[Node] Server running on port ${PORT}`);
});
